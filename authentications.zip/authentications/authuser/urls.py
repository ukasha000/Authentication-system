from django.contrib import admin
from django.urls import path , include
from authuser import views
from Userprofile import views as user_views


urlpatterns = [
    path('' , views.home , name='home'),
    path('signup' , views.signupuser , name='signup'),
    path('signin' , views.signinuser , name='signin'),
    path('signout' , views.signoutuser , name='signout'),
    path('musics' , views.musics , name='musics'),
    path('songs/<int:id>' , views.songpost , name='songpost'),
    path('authuser/musics' , views.musics , name='song'),
    path('songs/authuser/musics' , views.musics , name='song'),
    path('forget-password' , views.forget_password , name='forget_password'),
    path('change-password/<token>' , views.change_password , name='change_password'),
    path('activate/<uidb64>/<token>' , views.activate , name='activate'),
    path('watchlater' , views.watchlater , name='watchlater'),
    path('profile/' , user_views.UserProfile , name='profile'),
] 