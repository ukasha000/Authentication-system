from django.shortcuts import render , HttpResponse , redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate , login , logout
from django.core.mail import send_mail , EmailMessage
from authentications import settings
from authuser.models import Profile, Song , WatchLater
from .helpers import send_forget_password_mail
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode , urlsafe_base64_decode
from django.utils.encoding import force_bytes , force_str
from .email_verification import generate_token
from django.db.models import Case , When 
import uuid
# Create your views here.
def home(request):
    return render(request , 'authuser/index.html')
def signupuser(request):
    if request.method == "POST":
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        if User.objects.filter(username=username).first():
            messages.error(request , "Username already exist! Please try some other username")
            return redirect('/signup')
        if User.objects.filter(email=email).first():
            messages.error(request , "Email already registered!")
            return redirect('/signup')
        if password!=confirm_password:
            messages.error(request , "Passwords didn't match!")
            return redirect('/signup')
        if not fname or not lname or not username or not email or not password or not confirm_password:
            messages.success(request , "Each entry must be filled!")
            return redirect('/signup')
        if not username.isalnum():
            messages.error(request , "Username must be Aplha-Numeric!")
            return redirect('/signup')
        user_obj = User(username=username , email=email)
        user_obj.set_password(password)
        user_obj.is_active = False
        user_obj.first_name=fname
        user_obj.last_name=lname
        user_obj.save()

        profile_obj = Profile.objects.create(user=user_obj)
        profile_obj.save()
        messages.success(request , "Your Account Has Been Created Successfully.Please Confirm Your Email.")
        #email
        subject = "Welcome to music beast"
        message = "Hello" + user_obj.username + "!! \n" + "welcome to music beast!! \n Thank You for visiting our website \n We have also send you a confirmation email, Please confirm your email address in order to activate your account. \n\n Thanking You\n Ukasha Hassan"
        from_email = settings.EMAIL_HOST_USER
        to_list = [user_obj.email]
        send_mail(subject , message , from_email , to_list , fail_silently=True)
        #Email for verification
        current_site = get_current_site(request)
        email_subject = "Confirm Your Email -- MUSIC BEAST LOGIN -- "
        message2 = render_to_string('email_confirmation.html' , {'name' : user_obj.username , 'domain' : current_site.domain , 'uid' : urlsafe_base64_encode(force_bytes(user_obj.pk)) , 'token' : generate_token.make_token(user_obj)})
        email = EmailMessage(
            email_subject,
            message2,
            settings.EMAIL_HOST_USER,
            [user_obj.email],
        )
        email.fail_silently = True
        email.send()
        return redirect('/signin')
    return render(request , 'authuser/signup.html')
def signinuser(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        if not username or not password:
            messages.success(request , "Both Username and Password are required!")
            return redirect('/signin')
        user_obj = User.objects.filter(username=username).first()
        if user_obj is None:
            messages.success(request , "User not found!")
            return redirect('/signin ')
        user = authenticate(username=username , password=password)
        if user is not None:
            messages.success(request , "logged In Successfully!")
            login(request , user)
            return redirect('/musics')
        else:
            messages.error(request , "Incorrect Username Or Password")
            return render(request , 'authuser/signin.html')
    return render(request , 'authuser/signin.html')
def signoutuser(request):
    logout(request)
    messages.success(request , "logged Out Successfully!")
    return render(request , 'authuser/index.html')
def musics(request):
    if request.user.is_anonymous:
        messages.error(request , "Please Signup or Login!")
        return redirect('/')
    song = Song.objects.all()
    return render(request , 'authuser/musics.html' , {'song': song})
'''def songs(request):
    song = Song.objects.all()
    return render(request , 'authuser/songs.html' , {'song': song})'''
def songpost(request , id):
    if request.user.is_anonymous:
        messages.error(request , "Please Signup or Login!")
        return redirect('/')
    song = Song.objects.filter(song_id=id).first()
    return render(request , 'authuser/songpost.html' , {'song': song})
def forget_password(request):
    if request.method == "POST":
        username = request.POST.get('username')
        if not User.objects.filter(username=username).first():
            messages.error(request , "User not found!")
            return redirect('/forget-password')
        user_obj = User.objects.get(username=username)
        token = str(uuid.uuid4())
        profile_obj = Profile.objects.get(user = user_obj)
        profile_obj.forget_password_token = token
        profile_obj.save()
        send_forget_password_mail(user_obj.email , token)
        messages.success(request , "An email is sent")
        return redirect('/forget-password')
    return render(request , 'authuser/forget-password.html')
def change_password(request , token):
    context = {}
    profile_obj = Profile.objects.filter(forget_password_token = token).first()
    context = {'user_id' : profile_obj.user.id}
    if request.method == "POST":
         new_password = request.POST.get('new_password')
         confirm_password = request.POST.get('confirm_password')
         user_id = request.POST.get('user_id')
         if user_id is None:
            messages.error(request , 'No user id found.')
            return redirect('/change-password/{token}')
         if new_password != confirm_password:
            messages.error(request , "Both should be equal")
            return redirect('/change-password/{token}')
         user_obj = User.objects.get(id=user_id)
         user_obj.set_password(new_password)
         user_obj.save()
         return redirect('/signin')
    return render(request , 'authuser/change-password.html' , context)
def activate(request , uidb64 , token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user_obj = User.objects.get(pk=uid)
    except (TypeError , ValueError , OverflowError , User.DoesNotExist):
        user_obj = None
    if user_obj is not None and generate_token.check_token(user_obj , token):
        user_obj.is_active = True
        user_obj.save()
        messages.success(request , "Email Confirmation Successfull.Please Sign In.")
        return redirect('/signin')
    else:
        return render(request , 'activation_failed.html')
def watchlater(request):
    if request.user.is_anonymous:
        messages.error(request , "Please Signup or Login!")
        return redirect('/')
    if request.method == "POST":
        user = request.user
        video_id = request.POST['video_id']
        watch = WatchLater.objects.filter(user=user)
        for i in watch:
            if video_id == i.video_id:
                message = "Your video is already added"
                break
        else:
            watchlater = WatchLater(user=user , video_id=video_id)
            watchlater.save()
            message = "Your video is successfully added"
        song = Song.objects.filter(song_id=video_id).first()
        return render(request , 'authuser/songpost.html' , {'song' : song , 'message' : message})
    wl = WatchLater.objects.filter(user=request.user)
    ids = []
    for i in wl:
        ids.append(i.video_id)
    preserved = Case(*[When(pk=pk , then=pos) for pos , pk in enumerate(ids)])
    song = Song.objects.filter(song_id__in=ids).order_by(preserved)
    return render(request , 'authuser/watchlater.html' , {'song' : song})
