from django.contrib import admin
from authuser.models import Song
from authuser.models import Profile
from authuser.models import WatchLater
from authuser.models import User
admin.site.register(Song)
admin.site.register(Profile)
admin.site.register(WatchLater)
